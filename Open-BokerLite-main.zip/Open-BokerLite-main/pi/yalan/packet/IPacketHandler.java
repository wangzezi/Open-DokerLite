package pi.yalan.packet;

public interface IPacketHandler {
}
