import cn.BokerLite.Client;

public class DebugLoader {
    public DebugLoader(){
        new Client("BokerLite");
    }
}
