package cn.BokerLite.gui.clickgui.windows;

import cn.BokerLite.gui.clickgui.components.ModuleWindow;

public class FriendWindow extends ModuleWindow {
    public FriendWindow() {
        super("Friend", "好友管理");
        this.x = 0.9;
        this.y = 0.7;
    }
}
