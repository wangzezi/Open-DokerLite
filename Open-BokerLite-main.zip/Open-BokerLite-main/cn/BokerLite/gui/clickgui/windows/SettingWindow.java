package cn.BokerLite.gui.clickgui.windows;

import cn.BokerLite.gui.clickgui.components.SubWindow;

public class SettingWindow extends SubWindow {
    public SettingWindow() {
        super("Global", "全局设置");
        this.x = 0.8;
        this.y = 0.8;
    }
}
