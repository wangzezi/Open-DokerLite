package cn.BokerLite.gui.clickgui.windows;

import cn.BokerLite.gui.clickgui.components.ModuleWindow;

public class ScriptWindow extends ModuleWindow {
    public ScriptWindow() {
        super("Script", "脚本管理");
        this.x = 0.4;
        this.y = 0.7;
    }
}
