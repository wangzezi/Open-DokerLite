package cn.BokerLite.gui.clickgui.windows;

import cn.BokerLite.gui.clickgui.components.SubWindow;

public class MainWindow extends SubWindow {
    public MainWindow() {
        super("GUI", "界面");
        this.x = this.y = 0.45;
    }
}
