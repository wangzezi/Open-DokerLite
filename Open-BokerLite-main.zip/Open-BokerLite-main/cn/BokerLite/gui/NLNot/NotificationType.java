package cn.BokerLite.gui.NLNot;

public enum NotificationType {
    SUCCESS,
    DISABLE,
    INFO,
    WARNING
}
