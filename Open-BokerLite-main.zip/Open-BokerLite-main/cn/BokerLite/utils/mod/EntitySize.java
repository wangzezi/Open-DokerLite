package cn.BokerLite.utils.mod;

public class EntitySize {
    public float width;
    public float height;

    public EntitySize(float width, float height) {
        this.width = width;
        this.height = height;
    }
}
