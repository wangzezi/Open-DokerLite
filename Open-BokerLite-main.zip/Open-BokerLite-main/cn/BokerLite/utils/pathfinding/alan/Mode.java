package cn.BokerLite.utils.pathfinding.alan;

public enum Mode {
    NORMAL,
    LEGIT
}
