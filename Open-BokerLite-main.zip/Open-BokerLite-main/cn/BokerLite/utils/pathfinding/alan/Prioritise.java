package cn.BokerLite.utils.pathfinding.alan;

public enum Prioritise {
    FASTEST_PATH,
    LEAST_POINTS
}
