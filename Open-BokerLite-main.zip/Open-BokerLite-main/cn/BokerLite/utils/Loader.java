package cn.BokerLite.utils;

import cn.BokerLite.Client;

public class Loader {
    public Loader(String token) {
    	new Client(token);
    }
}
