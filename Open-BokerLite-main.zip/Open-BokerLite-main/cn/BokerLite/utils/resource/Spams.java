package cn.BokerLite.utils.resource;

public class Spams {
    public static String[] spams = new String[]{
            "主播不办事开不明白",
            "主播是不是开的Vape啊",
            "bapeclient.xyz > getvapu.today",
            "Bape > could",
            "免费GC殴打DoMcer，下载链接 bapeclient.xyz",
            "主播是不是不会开，火速下载吴雨桐大神最新GC注入伺服器",
            "Water client > lunar client",
            "主播我的常用密码是wuyutong233",
            "Water client better than Badlion client",
            "主播是不是不会开端开不明白，让你亲娘吴雨桐教你",
            "主播不办事，你的客户端是不是没混淆被裂了，火速下载Water!",
            "Water visual > tenacity and zeroday",
            "Water FPS > feather client",
            "Tenacity skidding Water lol",
            "Hacked by Czf_233",
            "N00B, get the best get bape",
            "get r3kt get lose get more suck, get tenacity",
            "Water > sigma",
            "James java better than LeakedPVP"
    };
}
