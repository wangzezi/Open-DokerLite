package cn.BokerLite.command.commands;


import cn.BokerLite.api.enums.ACType;
import cn.BokerLite.command.Command;
import cn.BokerLite.irc.Auth;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import pi.yalan.packet.client.CMessagePacket;

import java.io.IOException;

public class IRC extends Command {
    public IRC(){

        super("IRC", new String[]{"irc"}, "Set Module Binds", ACType.Module);

    }

    @Override
    public String execute(String[] args) {



        final StringBuilder message = new StringBuilder();


        message.append(args[0]);



        try {
            Auth.Instance.sendPacket(new CMessagePacket(message.toString()));
        } catch (IOException e) {
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("Cannot send chat: " + e.getClass().getName() + ":" + e.getMessage()));

            e.printStackTrace();
        }
        return null;
    }
    }


