package cn.BokerLite.modules.move;

import net.minecraft.util.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import cn.BokerLite.modules.Module;
import cn.BokerLite.modules.ModuleType;
import cn.BokerLite.utils.timer.TimerUtil;

public class AntiVoid extends Module {
    public final TimerUtil timer = new TimerUtil();
    public boolean saveMe;
    public AntiVoid() {
        super("AntiVoid","虚空回弹", Keyboard.KEY_NONE, ModuleType.Movement, "Void Pullback",ModuleType.SubCategory.MOVEMENT_MAIN);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent e) {
        if (mc.thePlayer.fallDistance > 1.0) {
            if ((!isBlockUnder())) {
                if (!this.saveMe) {
                    this.saveMe = true;
                    this.timer.reset();
                }
                mc.thePlayer.setPosition(mc.thePlayer.posX + 1, mc.thePlayer.posY + 1.0, mc.thePlayer.posZ);
            }
        }
    }

    public boolean isBlockUnder() {
        if (mc.thePlayer.posY < 0)
            return false;
        for (int off = 0; off < (int) mc.thePlayer.posY + 2; off += 2) {
            AxisAlignedBB bb = mc.thePlayer.getEntityBoundingBox().offset(0, -off, 0);
            if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, bb).isEmpty()) {
                return true;
            }
        }
        return false;
    }
}


