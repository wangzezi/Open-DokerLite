package linxiu.module.modules.combat;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import linxiu.Client;
import linxiu.api.Event;
import linxiu.api.EventBus;
import linxiu.api.EventHandler;
import linxiu.api.events.rendering.EventRender2D;
import linxiu.api.events.rendering.EventRender3D;
import linxiu.api.events.world.EventAttack;
import linxiu.api.events.world.EventPostUpdate;
import linxiu.api.events.world.EventPreUpdate;
import linxiu.api.events.world.EventTick;
import linxiu.api.value.Mode;
import linxiu.api.value.Numbers;
import linxiu.api.value.Option;
import linxiu.injection.interfaces.IEntityLivingBase;
import linxiu.injection.interfaces.IEntityPlayer;
import linxiu.injection.interfaces.IRenderManager;
import linxiu.management.FriendManager;
import linxiu.management.ModuleManager;
import linxiu.module.Module;
import linxiu.module.ModuleType;
import linxiu.module.modules.combat.AntiBot;
import linxiu.module.modules.combat.KillAura;
import linxiu.module.modules.movement.Scaffold;
import linxiu.module.modules.player.Teams;
import linxiu.module.modules.render.HUD;
import linxiu.ui.notification.Notification;
import linxiu.utils.Helper;
import linxiu.utils.PacketUtils;
import linxiu.utils.math.MathUtil;
import linxiu.utils.math.RotationUtil;
import linxiu.utils.math.RotationUtils;
import linxiu.utils.math.Vec3d;
import linxiu.utils.render.RenderUtil;
import linxiu.utils.render.RenderUtils;
import linxiu.utils.timer.TimeHelper;
import linxiu.utils.timer.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

/*
 * Exception performing whole class analysis ignored.
 */
public class KillAura
        extends Module {
    public final Numbers<Number> switchDelayValue;
    public final Numbers<Number> MINValue;
    public static final Option<Boolean> preferValue;
    private Mode<Enum> APSmode;
    private final TimerUtil blockPreventFlagTimer;
    TimerUtil timerUtil;
    public TimeHelper attacktimer = new TimeHelper();
    public final Numbers<Number> wallRangeValue;
    public final Numbers<Number> attackRangeValue;
    public static final Option<Boolean> monsterValue;
    public static EntityLivingBase vip;
    public static final Option<Boolean> playerValue;
    public static final Option<Boolean> smoothValue;
    public static final Option<Boolean> HeadValue;
    public static Mode<Enum> mode4;
    public static final Option<Boolean> keepsprintvalue;
    public static final Option<Boolean> neutralValue;
    public static final Option<Boolean> RotValue;
    private final TimeHelper RotTimer;
    public TimeHelper renderTimer;
    private final ArrayList<EntityLivingBase> targetList;
    public static final Option<Boolean> RayCast;
    public float[] facing;
    private final TimeHelper switchTimer;
    public final Numbers<Number> fovValue;
    private Mode<Enum> mode2;
    public final Numbers<Number> MAXT;
    float yPos;
    public final Numbers<Number> MAXValue;
    public static final Option<Boolean> multi;
    private boolean direction;
    public final Numbers<Number> minrangeValue;
    public static final Option<Boolean> onlySwordsTools;
    public static final Option<Boolean> deathValue;
    private float alpha;
    public static float yaw;
    public static EntityLivingBase target;
    private Mode<Enum> Priority;
    private int index;
    public static final Option<Boolean> exhvalue;
    public static float pitch;
    public static final Option<Boolean> invisibleValue;
    private Mode<Enum> mode;
    public static final Option<Boolean> animalValue;
    public final Numbers<Number> maxrangeValue;
    public static final Option<Boolean> throughWallValue;
    private Comparator<Entity> angleComparator;
    private static EntityLivingBase blockTarget;
    public static boolean blocking;
    public static final Option<Boolean> autoBlockValue;

    private static int lambda$raysy$9(Entity entity, MovingObjectPosition movingObjectPosition, MovingObjectPosition movingObjectPosition2) {
        Vec3 vec3 = entity.getPositionEyes(1.0f);
        return (int)((vec3.distanceTo(movingObjectPosition.hitVec) - vec3.distanceTo(movingObjectPosition2.hitVec)) * 100.0);
    }

    public boolean ShouldAttack() {
        int n = ((Number)this.MINValue.getValue()).intValue();
        int n2 = ((Number)this.MAXValue.getValue()).intValue();
        int n3 = MathUtil.getRandom((int)n, (int)n2);
        if (this.APSmode.getValue() == APSMode.Jello) {
            return this.attacktimer.isDelayComplete(Double.valueOf((double)(Math.random() * (double)(1000 / n3))));
        }
        if (this.APSmode.getValue() == APSMode.Zeriy) {
            return this.attacktimer.isDelayComplete(KillAura.randomClickDelay(n - 1, n2 + 1));
        }
        return this.attacktimer.isDelayComplete((long)(1000 / n3));
    }

    public static EntityLivingBase getTarget() {
        return target;
    }

    @EventHandler
    private void onUpdate(EventPreUpdate eventPreUpdate) {
        if (!((Boolean)onlySwordsTools.getValue()).booleanValue() || this.mc.thePlayer.getHeldItem().getItem() != null && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
            blockTarget = null;
            for (Entity entity : this.mc.theWorld.getLoadedEntityList()) {
                EntityLivingBase entityLivingBase;
                if (!(entity instanceof EntityLivingBase) || !this.getEntityValidBlock(entityLivingBase = (EntityLivingBase)entity)) continue;
                blockTarget = entityLivingBase;
                break;
            }
            target = null;
            this.targetList.clear();
            int n = ((Number)this.MAXT.getValue()).intValue();
            for (EntityLivingBase entityLivingBase : this.mc.theWorld.getLoadedEntityList()) {
                EntityLivingBase entityLivingBase2;
                if (!(entityLivingBase instanceof EntityLivingBase) || !this.getEntityValid(entityLivingBase2 = entityLivingBase)) continue;
                if (vip == entityLivingBase2) {
                    this.targetList.clear();
                    this.targetList.add((Object)entityLivingBase2);
                    break;
                }
                this.targetList.add((Object)entityLivingBase2);
                if (!((Boolean)multi.getValue()).booleanValue() && this.targetList.size() >= n) break;
                if (this.Priority.getValue() == priority.Armor) {
                    this.targetList.sort(Comparator.comparingInt(KillAura::lambda$onUpdate$1));
                }
                if (this.Priority.getValue() == priority.Range) {
                    this.targetList.sort(this::lambda$onUpdate$2);
                }
                if (this.Priority.getValue() == priority.Fov) {
                    this.targetList.sort(Comparator.comparingDouble(this::lambda$onUpdate$3));
                }
                if (this.Priority.getValue() == priority.Angle) {
                    this.targetList.sort(this::lambda$onUpdate$4);
                }
                if (this.Priority.getValue() != priority.Health) continue;
                this.targetList.sort(Comparator.comparingDouble(EntityLivingBase::getHealth));
            }
            if (((Boolean)preferValue.getValue()).booleanValue()) {
                for (EntityLivingBase entityLivingBase : this.targetList) {
                    if (!(entityLivingBase instanceof EntityWither)) continue;
                    this.targetList.clear();
                    this.targetList.add((Object)entityLivingBase);
                    break;
                }
            }
            if (this.switchTimer.isDelayComplete((long)((Number)this.switchDelayValue.getValue()).intValue() * 100L) && this.targetList.size() > 1) {
                this.switchTimer.reset();
                ++this.index;
            }
            if (this.index >= this.targetList.size()) {
                this.index = 0;
            }
            if (!this.targetList.isEmpty()) {
                target = (EntityLivingBase)this.targetList.get(this.mode.getValue() == AuraMode.Switch ? this.index : 0);
            }
        }
    }

    private int lambda$targetsSort$6(EntityLivingBase entityLivingBase, EntityLivingBase entityLivingBase2) {
        return (int)(entityLivingBase.getDistanceToEntity((Entity)this.mc.thePlayer) - entityLivingBase2.getDistanceToEntity((Entity)this.mc.thePlayer));
    }

    @EventHandler
    public void onRender3D2(EventRender3D eventRender3D) {
        if (!((Boolean)onlySwordsTools.getValue()).booleanValue() || this.mc.thePlayer.getHeldItem().getItem() != null && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
            double d;
            double d2;
            double d3;
            if (target != null && this.mode2.getValue() == ESPMode.Platform) {
                for (EntityLivingBase entityLivingBase : this.targetList) {
                    RenderUtils.drawAuraMark((Entity)entityLivingBase, (Color)(KillAura.target.hurtTime > 3 ? new Color(0, 255, 88, 75) : new Color(235, 40, 40, 75)));
                }
            }
            if (target != null && this.mode2.getValue() == ESPMode.Rise) {
                for (EntityLivingBase entityLivingBase : this.targetList) {
                    this.draw2Shadow((Entity)entityLivingBase, 0.67, new Color(((Number)HUD.r.getValue()).intValue(), ((Number)HUD.g.getValue()).intValue(), ((Number)HUD.b.getValue()).intValue()).getRGB(), true);
                }
            }
            if (target != null && this.mode2.getValue() == ESPMode.Jello) {
                this.drawShadow((Entity)target, eventRender3D.getPartialTicks(), this.yPos, this.direction);
                this.drawCircle((Entity)target, eventRender3D.getPartialTicks(), this.yPos);
            }
            if (target == null || this.mode2.getValue() == ESPMode.Diamond) {
                // empty if block
            }
            if (target != null && this.mode2.getValue() == ESPMode.Box) {
                for (EntityLivingBase entityLivingBase : this.targetList) {
                    RenderUtils.drawPlatform((Entity)entityLivingBase, (Color)(KillAura.target.hurtTime > 3 ? new Color(0, 255, 88, 75) : new Color(235, 40, 40, 75)));
                }
            }
            if (this.mode2.getValue() == ESPMode.Vape) {
                for (EntityLivingBase entityLivingBase : this.targetList) {
                    this.mc.getRenderManager();
                    d3 = entityLivingBase.lastTickPosX + (entityLivingBase.posX - entityLivingBase.lastTickPosX) * (double)Helper.getTimer().renderPartialTicks - ((IRenderManager)this.mc.getRenderManager()).getRenderPosX();
                    this.mc.getRenderManager();
                    d2 = entityLivingBase.lastTickPosY + (entityLivingBase.posY - entityLivingBase.lastTickPosY) * (double)Helper.getTimer().renderPartialTicks - ((IRenderManager)this.mc.getRenderManager()).getRenderPosY();
                    this.mc.getRenderManager();
                    d = entityLivingBase.lastTickPosZ + (entityLivingBase.posZ - entityLivingBase.lastTickPosZ) * (double)Helper.getTimer().renderPartialTicks - ((IRenderManager)this.mc.getRenderManager()).getRenderPosZ();
                    double d4 = entityLivingBase.getEntityBoundingBox().maxX - entityLivingBase.getEntityBoundingBox().minX - 0.1;
                    double d5 = entityLivingBase.getEntityBoundingBox().maxY - entityLivingBase.getEntityBoundingBox().minY + 0.05;
                    float f = 220.0f - (float)(entityLivingBase.hurtTime * 5) / 255.0f;
                    float f2 = (float)(entityLivingBase.hurtTime * 10) / 255.0f;
                    float f3 = (float)(entityLivingBase.hurtTime * 2) / 255.0f;
                    float f4 = (float)(80 + entityLivingBase.hurtTime * 10) / 255.0f;
                    float f5 = 220.0f - (float)(entityLivingBase.hurtTime * 5) / 255.0f;
                    float f6 = (float)(entityLivingBase.hurtTime * 10) / 255.0f;
                    float f7 = (float)(entityLivingBase.hurtTime * 2) / 255.0f;
                    float f8 = (float)(80 + entityLivingBase.hurtTime * 10) / 500.0f;
                    if (entityLivingBase.hurtTime >= 1) {
                        RenderUtil.drawEntityESP((double)d3, (double)d2, (double)d, (double)d4, (double)d5, (float)f, (float)f2, (float)f3, (float)f4, (float)0.1f, (float)0.1f, (float)0.1f, (float)0.1f, (float)0.1f);
                        continue;
                    }
                    RenderUtil.drawEntityESP((double)d3, (double)d2, (double)d, (double)d4, (double)d5, (float)f, (float)f2, (float)f3, (float)f8, (float)0.1f, (float)0.1f, (float)0.1f, (float)0.1f, (float)0.1f);
                }
            }
            if (this.mode2.getValue() == ESPMode.Novoline) {
                double d6;
                RenderUtils.pre3D();
                GL11.glLineWidth((float)6.0f);
                GL11.glBegin((int)3);
                GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)this.alpha);
                for (d6 = 0.0; d6 < Math.PI * 2; d6 += 0.12319971190548208) {
                    d3 = this.mc.thePlayer.lastTickPosX + (this.mc.thePlayer.posX - this.mc.thePlayer.lastTickPosX) * (double)eventRender3D.getPartialTicks() + Math.sin((double)d6) * ((Number)this.minrangeValue.getValue()).doubleValue() - ((IRenderManager)this.mc.getRenderManager()).getRenderPosX();
                    d2 = this.mc.thePlayer.lastTickPosY + (this.mc.thePlayer.posY - this.mc.thePlayer.lastTickPosY) * (double)eventRender3D.getPartialTicks() - ((IRenderManager)this.mc.getRenderManager()).getRenderPosY();
                    d = this.mc.thePlayer.lastTickPosZ + (this.mc.thePlayer.posZ - this.mc.thePlayer.lastTickPosZ) * (double)eventRender3D.getPartialTicks() + Math.cos((double)d6) * ((Number)this.minrangeValue.getValue()).doubleValue() - ((IRenderManager)this.mc.getRenderManager()).getRenderPosZ();
                    GL11.glVertex3d((double)d3, (double)d2, (double)d);
                }
                GL11.glEnd();
                GL11.glLineWidth((float)3.0f);
                GL11.glBegin((int)3);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                for (d6 = 0.0; d6 < Math.PI * 2; d6 += 0.12319971190548208) {
                    d3 = this.mc.thePlayer.lastTickPosX + (this.mc.thePlayer.posX - this.mc.thePlayer.lastTickPosX) * (double)eventRender3D.getPartialTicks() + Math.sin((double)d6) * ((Number)this.minrangeValue.getValue()).doubleValue() - ((IRenderManager)this.mc.getRenderManager()).getRenderPosX();
                    d2 = this.mc.thePlayer.lastTickPosY + (this.mc.thePlayer.posY - this.mc.thePlayer.lastTickPosY) * (double)eventRender3D.getPartialTicks() - ((IRenderManager)this.mc.getRenderManager()).getRenderPosY();
                    d = this.mc.thePlayer.lastTickPosZ + (this.mc.thePlayer.posZ - this.mc.thePlayer.lastTickPosZ) * (double)eventRender3D.getPartialTicks() + Math.cos((double)d6) * ((Number)this.minrangeValue.getValue()).doubleValue() - ((IRenderManager)this.mc.getRenderManager()).getRenderPosZ();
                    GL11.glVertex3d((double)d3, (double)d2, (double)d);
                }
                GL11.glEnd();
                RenderUtils.post3D();
            }
        }
    }

    public static float getSensitivityMultiplier() {
        float f = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6f + 0.2f;
        return f * f * f * 8.0f * 0.15f;
    }

    private static int lambda$onUpdate$1(EntityLivingBase entityLivingBase) {
        return entityLivingBase instanceof EntityPlayer ? ((EntityPlayer)entityLivingBase).inventory.getTotalArmorValue() : (int)entityLivingBase.getHealth();
    }

    @EventHandler
    public void onosoda(EventPreUpdate eventPreUpdate) {
        if ((!((Boolean)onlySwordsTools.getValue()).booleanValue() || this.mc.thePlayer.getHeldItem().getItem() != null && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) && ((Boolean)RotValue.getValue()).booleanValue()) {
            if (!((Boolean)exhvalue.getValue()).booleanValue()) {
                Object object;
                Object object2;
                float[] fArray;
                if (this.mc.playerController.getIsHittingBlock()) {
                    return;
                }
                if (target != null) {
                    if (!this.RotTimer.hasReached(350L)) {
                        eventPreUpdate.setYaw(yaw);
                        eventPreUpdate.setPitch(pitch);
                    } else {
                        yaw = this.mc.thePlayer.rotationYaw;
                        pitch = this.mc.thePlayer.rotationPitch;
                    }
                }
                if (target != null && this.RotTimer.hasReached(150L) && !this.RotTimer.hasReached(350L) && ((Boolean)smoothValue.getValue()).booleanValue()) {
                    Client.getModuleManager();
                    if (!ModuleManager.getModuleByClass(Scaffold.class).isEnabled()) {
                        fArray = new float[]{yaw, pitch};
                        object2 = new float[]{this.mc.thePlayer.rotationYaw, Math.max((float)Math.min((float)this.mc.thePlayer.rotationPitch, (float)90.0f), (float)-90.0f)};
                        object = this.Zenith((float[])object2, fArray);
                        yaw = object[0];
                        pitch = Math.max((float)Math.min((float)object[1], (float)90.0f), (float)-90.0f);
                    }
                }
                if (target != null) {
                    Object object3;
                    Object object4;
                    this.RotTimer.reset();
                    fArray = this.lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII(target);
                    float f = MathHelper.wrapAngleTo180_float((float)(fArray[0] - yaw));
                    if (((Boolean)smoothValue.getValue()).booleanValue()) {
                        float[] fArray2 = new float[]{yaw, pitch};
                        object4 = new float[]{yaw + f, Math.max((float)Math.min((float)fArray[1], (float)90.0f), (float)-90.0f)};
                        object3 = this.Zenith((float[])object4, fArray2);
                        yaw = object3[0];
                        pitch = Math.max((float)Math.min((float)object3[1], (float)90.0f), (float)-90.0f);
                        boolean bl = false;
                        if (!this.raysy(yaw, pitch).isEmpty()) {
                            object = this.raysy(yaw, pitch).iterator();
                            while (object.hasNext()) {
                                object2 = (MovingObjectPosition)object.next();
                                if (object2.entityHit == this.mc.thePlayer || object2.entityHit != target) continue;
                                bl = true;
                                break;
                            }
                        }
                        if (!bl) {
                            RayCast.getValue();
                        }
                    } else {
                        float f2 = MathHelper.wrapAngleTo180_float((float)(fArray[0] - yaw)) / 2.0f;
                        yaw = (float)((double)(yaw + f) + ThreadLocalRandom.current().nextGaussian() * 1.1);
                        pitch = (float)Math.max((double)Math.min((double)((double)fArray[1] + ThreadLocalRandom.current().nextGaussian()), (double)90.0), (double)-90.0);
                    }
                    boolean bl = false;
                    object4 = target;
                    if (!this.raysy(yaw, pitch).isEmpty()) {
                        object3 = this.raysy(yaw, pitch).iterator();
                        while (object3.hasNext()) {
                            MovingObjectPosition movingObjectPosition = (MovingObjectPosition)object3.next();
                            if (((Boolean)RayCast.getValue()).booleanValue() && movingObjectPosition.entityHit != null && movingObjectPosition.entityHit != this.mc.thePlayer && this.getEntityValid((EntityLivingBase)movingObjectPosition.entityHit)) {
                                object4 = (EntityLivingBase)movingObjectPosition.entityHit;
                                bl = true;
                                break;
                            }
                            if (movingObjectPosition.entityHit == this.mc.thePlayer || movingObjectPosition.entityHit == null || movingObjectPosition.entityHit != object4) continue;
                            bl = true;
                            break;
                        }
                    }
                }
            }
            if (target != null) {
                if (!this.RotTimer.hasReached(350L)) {
                    eventPreUpdate.setYaw(yaw);
                    eventPreUpdate.setPitch(pitch);
                } else {
                    yaw = this.mc.thePlayer.rotationYaw;
                    pitch = this.mc.thePlayer.rotationPitch;
                }
            }
        }
    }

    private int lambda$onUpdate$2(EntityLivingBase entityLivingBase, EntityLivingBase entityLivingBase2) {
        return (int)(entityLivingBase.getDistanceToEntity((Entity)this.mc.thePlayer) - entityLivingBase2.getDistanceToEntity((Entity)this.mc.thePlayer));
    }

    @EventHandler
    public void onoso2da(EventPreUpdate eventPreUpdate) {
        if ((!((Boolean)onlySwordsTools.getValue()).booleanValue() || this.mc.thePlayer.getHeldItem().getItem() != null && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) && ((Boolean)RotValue.getValue()).booleanValue()) {
            if (this.mc.playerController.getIsHittingBlock()) {
                return;
            }
            if (((Boolean)exhvalue.getValue()).booleanValue() && target != null) {
                float[] fArray = this.getRotations(target);
                eventPreUpdate.setYaw(fArray[0]);
                eventPreUpdate.setPitch(fArray[1]);
                Helper.mc.thePlayer.rotationYawHead = fArray[0];
                ((IEntityLivingBase)Helper.mc.thePlayer).setrotationPitchHead(fArray[1]);
            }
        }
    }

    private static double lambda$new$0(Entity entity) {
        return RotationUtil.getRotations((Entity)entity)[0];
    }

    public static long randomClickDelay(double d, double d2) {
        return (long)(Math.random() * (1000.0 / d - 1000.0 / d2 + 1.0) + 1000.0 / d2);
    }

    private void stopBlocking() {
        boolean bl;
        boolean bl2 = bl = this.mc.thePlayer.getHeldItem() != null && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword;
        if (((Boolean)autoBlockValue.getValue()).booleanValue() && blocking && !Mouse.isButtonDown((int)1) && bl) {
            blocking = false;
            KeyBinding.setKeyBindState((int)this.mc.gameSettings.keyBindUseItem.getKeyCode(), (boolean)false);
            this.mc.playerController.onStoppedUsingItem((EntityPlayer)this.mc.thePlayer);
            ((IEntityPlayer)this.mc.thePlayer).setItemInUseCount(0);
        }
        if (!this.hasSword((EntityPlayer)this.mc.thePlayer) && blocking) {
            blocking = false;
        }
    }

    private float[] Zenith(float[] fArray, float[] fArray2) {
        float[] fArray3 = new float[]{fArray2[0] - fArray[0], fArray2[1] - fArray[1]};
        fArray3 = KillAura.cahgnle(fArray3);
        float f = KillAura.random(20.0f, 30.0f);
        float f2 = KillAura.random(10.0f, 20.0f);
        if (target != null) {
            for (MovingObjectPosition movingObjectPosition : this.raysy(fArray2[0], fArray2[1])) {
                if (movingObjectPosition.entityHit == null || movingObjectPosition.entityHit == this.mc.thePlayer || !this.getEntityValid((EntityLivingBase)movingObjectPosition.entityHit)) continue;
                f2 = (float)((double)f2 * 0.3);
                break;
            }
        }
        fArray3[0] = fArray2[0] - fArray3[0] / 180.0f * (f / 2.0f);
        fArray3[1] = fArray2[1];
        fArray3[0] = RotationUtil.changeRotation((float)fArray3[0], (float)fArray[0], (float)f);
        fArray3[1] = RotationUtil.changeRotation((float)fArray3[1], (float)Math.max((float)Math.min((float)fArray[1], (float)90.0f), (float)-90.0f), (float)f2);
        return fArray3;
    }

    private int lambda$targetsSort$8(EntityLivingBase entityLivingBase, EntityLivingBase entityLivingBase2) {
        float[] fArray = RotationUtils.getNeededRotations((Entity)entityLivingBase);
        float[] fArray2 = RotationUtils.getNeededRotations((Entity)entityLivingBase2);
        return (int)(this.mc.thePlayer.rotationYaw - fArray[0] - (this.mc.thePlayer.rotationYaw - fArray2[0]));
    }

    @EventHandler
    private void onRender2D(EventRender2D eventRender2D) {
        if (this.timerUtil.hasTimeElapsed(10L)) {
            if (this.direction) {
                this.yPos = (float)((double)this.yPos + 0.03);
                if ((double)(2.0f - this.yPos) < 0.02) {
                    this.direction = false;
                }
            } else {
                this.yPos = (float)((double)this.yPos - 0.03);
                if ((double)this.yPos < 0.02) {
                    this.direction = true;
                }
            }
            this.timerUtil.reset();
        }
    }

    public static double SAOGANGONYOUSAOGANGONYOU(double d, double d2) {
        double d3;
        Random random = new Random();
        double d4 = d2 - d;
        double d5 = random.nextDouble() * d4;
        if (d5 > d2) {
            d5 = d2;
        }
        double d6 = d5 + d;
        if (d3 > d2) {
            d6 = d2;
        }
        return d6;
    }

    @EventHandler
    public final void On(EventTick eventTick) {
        if (target == null) {
            this.setSuffix("0 (0%)");
        }
        int n = 0;
        int n2 = 0;
        while (n2 < 101) {
            n = n2++;
        }
        n2 = ((Number)this.MINValue.getValue()).intValue();
        int n3 = ((Number)this.MAXValue.getValue()).intValue();
        int n4 = MathUtil.getRandom((int)n2, (int)n3);
        int n5 = 0;
        int n6 = 0;
        while (n6 < n4 + 1) {
            n5 = n6++;
        }
        int n7 = n6 = KillAura.target.hurtTime >= 1 ? n : this.randomNumber(40, 90);
        if (target != null && this.mc.thePlayer.ticksExisted % ((Number)HUD.Tick.getValue()).intValue() == 0) {
            this.setSuffix(String.valueOf((Object)new StringBuilder().append(n5).append(" (").append(n6).append("%)")));
        }
    }

    public static Vec3 getVectorForRotation(float f, float f2) {
        float f3 = MathHelper.cos((float)(-f * ((float)Math.PI / 180) - (float)Math.PI));
        float f4 = MathHelper.sin((float)(-f * ((float)Math.PI / 180) - (float)Math.PI));
        float f5 = -MathHelper.cos((float)(-f2 * ((float)Math.PI / 180)));
        float f6 = MathHelper.sin((float)(-f2 * ((float)Math.PI / 180)));
        return new Vec3((double)(f4 * f5), (double)f6, (double)(f3 * f5));
    }

    private float[] applyMouseSensFix(float f, float f2) {
        float f3 = this.mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
        float f4 = f3 * f3 * f3 * 1.2f;
        return new float[]{f, f2};
    }

    private void draw2Shadow(Entity entity, double d, int n, boolean bl) {
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2832);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glHint((int)3153, (int)4354);
        GL11.glDepthMask((boolean)false);
        GlStateManager.alphaFunc((int)516, (float)0.0f);
        if (bl) {
            GL11.glShadeModel((int)7425);
        }
        GlStateManager.disableCull();
        GL11.glBegin((int)5);
        double d2 = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)Helper.getTimer().renderPartialTicks - ((IRenderManager)this.mc.getRenderManager()).getRenderPosX();
        double d3 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)Helper.getTimer().renderPartialTicks - ((IRenderManager)this.mc.getRenderManager()).getRenderPosY() + Math.sin((double)((double)System.currentTimeMillis() / 200.0)) + 1.0;
        double d4 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)Helper.getTimer().renderPartialTicks - ((IRenderManager)this.mc.getRenderManager()).getRenderPosZ();
        float f = 0.0f;
        while ((double)f < Math.PI * 2) {
            double d5 = d2 + d * Math.cos((double)f);
            double d6 = d4 + d * Math.sin((double)f);
            Color color = new Color(255, 255, 255);
            Color color2 = new Color(((Number)HUD.r.getValue()).intValue(), ((Number)HUD.g.getValue()).intValue(), ((Number)HUD.b.getValue()).intValue());
            if (bl) {
                GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)0.0f);
                GL11.glVertex3d((double)d5, (double)(d3 - Math.cos((double)((double)System.currentTimeMillis() / 200.0)) / (double)2.9f), (double)d6);
                GL11.glColor4f((float)((float)color2.getRed() / 255.0f), (float)((float)color2.getGreen() / 255.0f), (float)((float)color2.getBlue() / 255.0f), (float)0.55f);
            }
            GL11.glVertex3d((double)d5, (double)d3, (double)d6);
            f = (float)((double)f + 0.09817477042468103);
        }
        GL11.glEnd();
        if (bl) {
            GL11.glShadeModel((int)7424);
        }
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
        GlStateManager.alphaFunc((int)516, (float)0.1f);
        GlStateManager.enableCull();
        GL11.glDisable((int)2848);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2832);
        GL11.glEnable((int)3553);
        GL11.glPopMatrix();
        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
    }

    private int randomNumber(int n, int n2) {
        return (int)(Math.random() * (double)(n - n2)) + n2;
    }

    public List<MovingObjectPosition> raysy(float f, float f2) {
        ArrayList arrayList = new ArrayList();
        Entity entity = this.mc.getRenderViewEntity();
        if (entity != null && this.mc.theWorld != null) {
            float f3 = target.getCollisionBorderSize();
            float f4 = 1.0f;
            Vec3 vec3 = entity.getPositionEyes(1.0f);
            Vec3 vec32 = KillAura.getVectorForRotation(f, f2);
            Vec3 vec33 = vec3.addVector(vec32.xCoord * (double)f3, vec32.yCoord * (double)f3, vec32.zCoord * (double)f3);
            List list = this.mc.theWorld.getEntitiesInAABBexcluding(entity, entity.getEntityBoundingBox().addCoord(vec32.xCoord * (double)f3, vec32.yCoord * (double)f3, vec32.zCoord * (double)f3).expand((double)f4, (double)f4, (double)f4), Predicates.and((Predicate)EntitySelectors.NOT_SPECTATING, Entity::canBeCollidedWith));
            for (int i = 0; i < list.size(); ++i) {
                Entity entity2 = (Entity)list.get(i);
                float f5 = entity2.getCollisionBorderSize();
                AxisAlignedBB axisAlignedBB = entity2.getEntityBoundingBox().expand((double)f5, (double)f5, (double)f5);
                MovingObjectPosition movingObjectPosition = axisAlignedBB.calculateIntercept(vec3, vec33);
                if (movingObjectPosition == null || entity2 == null) continue;
                movingObjectPosition.entityHit = entity2;
                arrayList.add((Object)new MovingObjectPosition(entity2, movingObjectPosition.hitVec));
            }
        }
        arrayList.sort((arg_0, arg_1) -> KillAura.lambda$raysy$9(entity, arg_0, arg_1));
        return arrayList;
    }

    public float[] NormalRes(float[] fArray) {
        float f = this.mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
        float f2 = f * f * f * 1.2f;
        return new float[]{fArray[0] - fArray[0] % f2, fArray[1] - fArray[1] % f2};
    }

    public boolean hitbox(Entity entity) {
        block12: {
            block11: {
                Client.getModuleManager();
                Teams teams = (Teams)ModuleManager.getModuleByClass(Teams.class);
                Client.getModuleManager();
                AntiBot antiBot = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
                if (!this.mc.thePlayer.isEntityAlive() || this.mc.thePlayer.isPlayerSleeping() || this.mc.thePlayer.isDead) break block11;
                if (!Teams.isOnSameTeam((Entity)entity) && !(this.mc.thePlayer.getHealth() <= 0.0f) && entity.isEntityAlive() && !entity.isDead && !(entity instanceof EntityArmorStand) && !antiBot.isBot(entity) && !this.isAutismShopKeeperCheck(entity) && entity != this.mc.thePlayer) break block12;
            }
            return false;
        }
        if (entity instanceof EntityPlayer) {
            EntityPlayer entityPlayer = (EntityPlayer)entity;
            if (FriendManager.isFriend((String)entityPlayer.getName())) {
                return false;
            }
            if (!((Boolean)playerValue.getValue()).booleanValue()) {
                return false;
            }
            if (entityPlayer.isPlayerSleeping()) {
                return false;
            }
            if (entityPlayer.isPotionActive(Potion.invisibility) && !((Boolean)invisibleValue.getValue()).booleanValue()) {
                return false;
            }
        }
        if (entity instanceof EntityAnimal) {
            return (Boolean)animalValue.getValue();
        }
        if (entity instanceof EntityMob) {
            return (Boolean)monsterValue.getValue();
        }
        if (entity instanceof EntityVillager || entity instanceof EntityIronGolem || entity instanceof EntitySnowman) {
            return (Boolean)neutralValue.getValue();
        }
        return true;
    }

    static {
        mode4 = new Mode("Render", (Enum[])RenderMode.values(), (Enum)RenderMode.Zenith);
        playerValue = new Option("Player", "Player", (Object)true);
        animalValue = new Option("Animal", "Animal", (Object)false);
        monsterValue = new Option("Monster", "Monster", (Object)false);
        neutralValue = new Option("Neutral", "Neutral", (Object)false);
        preferValue = new Option("Prefer", "Prefer", (Object)false);
        deathValue = new Option("Death", "Death", (Object)true);
        multi = new Option("Multi", "Multi", (Object)false);
        RayCast = new Option("RayCast", "RayCast", (Object)false);
        invisibleValue = new Option("Invisible", "invisible", (Object)false);
        onlySwordsTools = new Option("Only Swords", "Only Swords", (Object)false);
        throughWallValue = new Option("ThroughWall", "ThroughWall", (Object)false);
        HeadValue = new Option("Head Only", "Head Only", (Object)false);
        smoothValue = new Option("Smooth Aim", "Smooth Aim", (Object)true);
        exhvalue = new Option("Exhibition", "Exhibition", (Object)true);
        RotValue = new Option("Rotations", "Rotations", (Object)true);
        keepsprintvalue = new Option("KeepSprint", "KeepSprint", (Object)true);
        autoBlockValue = new Option("Auto Block", "Auto Block", (Object)false);
    }

    private boolean hasSword(EntityPlayer entityPlayer) {
        return entityPlayer.inventory.getCurrentItem() != null && entityPlayer.inventory.getCurrentItem().getItem() instanceof ItemSword;
    }

    public static double getRandomDoubleInRange(double d, double d2) {
        return d >= d2 ? d : new Random().nextDouble() * (d2 - d) + d;
    }

    public static float[] cahgnle(float[] fArray) {
        fArray[0] = fArray[0] % 360.0f;
        fArray[1] = fArray[1] % 360.0f;
        while (fArray[0] <= -180.0f) {
            fArray[0] = fArray[0] + 360.0f;
        }
        while (fArray[1] <= -180.0f) {
            fArray[1] = fArray[1] + 360.0f;
        }
        while (fArray[0] > 180.0f) {
            fArray[0] = fArray[0] - 360.0f;
        }
        while (fArray[1] > 180.0f) {
            fArray[1] = fArray[1] - 360.0f;
        }
        return fArray;
    }

    private int lambda$onUpdate$4(EntityLivingBase entityLivingBase, EntityLivingBase entityLivingBase2) {
        float[] fArray = RotationUtils.getNeededRotations((Entity)entityLivingBase);
        float[] fArray2 = RotationUtils.getNeededRotations((Entity)entityLivingBase2);
        return (int)(this.mc.thePlayer.rotationYaw - fArray[0] - (this.mc.thePlayer.rotationYaw - fArray2[0]));
    }

    public boolean getEntityValid(EntityLivingBase entityLivingBase) {
        block13: {
            block12: {
                Client.getModuleManager();
                AntiBot antiBot = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
                Client.getModuleManager();
                Teams teams = (Teams)ModuleManager.getModuleByClass(Teams.class);
                if (!this.mc.thePlayer.isEntityAlive() || this.mc.thePlayer.isPlayerSleeping() || this.mc.thePlayer.isDead || this.mc.thePlayer.getHealth() <= 0.0f) break block12;
                if (!Teams.isOnSameTeam((EntityLivingBase)entityLivingBase) && !((double)this.mc.thePlayer.getDistanceToEntity((Entity)entityLivingBase) >= (double)KillAura.random(((Number)this.minrangeValue.getValue()).floatValue(), ((Number)this.maxrangeValue.getValue()).floatValue())) && entityLivingBase.isEntityAlive() && !entityLivingBase.isDead && !(entityLivingBase.getHealth() <= 0.0f) && !(entityLivingBase instanceof EntityArmorStand) && !antiBot.isBot(entityLivingBase) && !this.isAutismShopKeeperCheck((Entity)entityLivingBase) && !this.notInFov((Entity)entityLivingBase) && entityLivingBase != this.mc.thePlayer) break block13;
            }
            return false;
        }
        if (entityLivingBase instanceof EntityPlayer) {
            boolean bl;
            EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            if (FriendManager.isFriend((String)entityPlayer.getName())) {
                return false;
            }
            if (!((Boolean)playerValue.getValue()).booleanValue()) {
                return false;
            }
            if (entityPlayer.isPlayerSleeping()) {
                return false;
            }
            boolean bl2 = bl = (Boolean)throughWallValue.getValue() == false || (double)this.mc.thePlayer.getDistanceToEntity((Entity)entityPlayer) >= (double)((Number)this.wallRangeValue.getValue()).floatValue();
            if (!RotationUtil.canEntityBeSeen((Entity)entityPlayer) && bl) {
                return false;
            }
            if (entityPlayer.isPotionActive(Potion.invisibility) && !((Boolean)invisibleValue.getValue()).booleanValue()) {
                return false;
            }
        }
        if (entityLivingBase instanceof EntityAnimal) {
            return (Boolean)animalValue.getValue();
        }
        if (entityLivingBase instanceof EntityMob) {
            return (Boolean)monsterValue.getValue();
        }
        if (entityLivingBase instanceof EntityVillager || entityLivingBase instanceof EntityIronGolem || entityLivingBase instanceof EntitySnowman) {
            return (Boolean)neutralValue.getValue();
        }
        return true;
    }

    @EventHandler
    void onWorldReload(EventPreUpdate eventPreUpdate) {
        if (this.mc.thePlayer.ticksExisted <= 1 && ((Boolean)deathValue.getValue()).booleanValue()) {
            Client.instance.getNotificationManager().getNotifications().add((Object)new Notification("Disabled aura due to death", 3000L));
            this.setEnabled(false);
        }
    }

    public void onDisable() {
        super.onDisable();
        if (this.mc.thePlayer.getItemInUseCount() == 999) {
            ((IEntityPlayer)this.mc.thePlayer).setItemInUseCount(0);
        }
        this.targetList.clear();
        target = null;
        blockTarget = null;
        this.stopBlocking();
    }

    public KillAura() {
        super("Kill Aura", new String[]{"ka", "aura", "killa"}, ModuleType.Combat);
        this.blockPreventFlagTimer = new TimerUtil();
        this.targetList = new ArrayList();
        this.angleComparator = Comparator.comparingDouble(KillAura::lambda$new$0);
        this.switchTimer = new TimeHelper();
        this.Priority = new Mode("Priority", (Enum[])priority.values(), (Enum)priority.Health);
        this.renderTimer = new TimeHelper();
        this.RotTimer = new TimeHelper();
        this.APSmode = new Mode("APS Mode", (Enum[])APSMode.values(), (Enum)APSMode.Zenith);
        this.mode = new Mode("Mode", (Enum[])AuraMode.values(), (Enum)AuraMode.Switch);
        this.mode2 = new Mode("ESP", (Enum[])ESPMode.values(), (Enum)ESPMode.Vape);
        this.switchDelayValue = new Numbers("SwitchDelay", "SwitchDelay", (Number)Double.valueOf((double)15.0), (Number)Double.valueOf((double)0.0), (Number)Double.valueOf((double)20.0), (Number)Double.valueOf((double)0.5));
        this.maxrangeValue = new Numbers("Max Reach", "Max Reach", (Number)Double.valueOf((double)4.2), (Number)Double.valueOf((double)1.0), (Number)Double.valueOf((double)8.0), (Number)Double.valueOf((double)0.05));
        this.minrangeValue = new Numbers("Min Reach", "Min Reach", (Number)Double.valueOf((double)4.2), (Number)Double.valueOf((double)1.0), (Number)Double.valueOf((double)8.0), (Number)Double.valueOf((double)0.05));
        this.MAXValue = new Numbers("Maximum APS.", "Maximum APS.", (Number)Double.valueOf((double)15.0), (Number)Double.valueOf((double)0.0), (Number)Double.valueOf((double)20.0), (Number)Double.valueOf((double)1.0));
        this.MINValue = new Numbers("Minimum APS.", "Minimum APS.", (Number)Double.valueOf((double)5.0), (Number)Double.valueOf((double)0.0), (Number)Double.valueOf((double)20.0), (Number)Double.valueOf((double)1.0));
        this.attackRangeValue = new Numbers("AttackRange", "AttackRange", (Number)Double.valueOf((double)5.0), (Number)Double.valueOf((double)1.0), (Number)Double.valueOf((double)15.0), (Number)Double.valueOf((double)0.05));
        this.wallRangeValue = new Numbers("WallRange", "WallRange", (Number)Double.valueOf((double)4.2), (Number)Double.valueOf((double)1.0), (Number)Double.valueOf((double)5.0), (Number)Double.valueOf((double)0.05));
        this.fovValue = new Numbers("Fov", "Fov", (Number)Double.valueOf((double)180.0), (Number)Double.valueOf((double)10.0), (Number)Double.valueOf((double)360.0), (Number)Double.valueOf((double)10.0));
        this.MAXT = new Numbers("MaxTarget", (Number)Double.valueOf((double)1.0), (Number)Double.valueOf((double)1.0), (Number)Double.valueOf((double)50.0), (Number)Double.valueOf((double)1.0));
        this.timerUtil = new TimerUtil();
        this.setColor(new Color(226, 54, 30).getRGB());
    }

    private double lambda$targetsSort$7(EntityLivingBase entityLivingBase) {
        return RotationUtils.getDistanceBetweenAngles((float)this.mc.thePlayer.rotationPitch, (float)RotationUtils.getNeededRotations((Entity)entityLivingBase)[0]);
    }

    private static int lambda$targetsSort$5(EntityLivingBase entityLivingBase) {
        return entityLivingBase instanceof EntityPlayer ? ((EntityPlayer)entityLivingBase).inventory.getTotalArmorValue() : (int)entityLivingBase.getHealth();
    }

    private void drawShadow(Entity entity, float f, float f2, boolean bl) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glShadeModel((int)7425);
        double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f - this.mc.getRenderManager().viewerPosX;
        double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f - this.mc.getRenderManager().viewerPosY + (double)f2;
        double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f - this.mc.getRenderManager().viewerPosZ;
        GL11.glBegin((int)8);
        for (int i = 0; i <= 180; ++i) {
            double d4 = (double)i * Math.PI * 2.0 / 180.0;
            double d5 = (double)(i + 1) * Math.PI * 2.0 / 180.0;
            Color color = new Color(HUD.getAstolfoColor((int)4000, (float)(i * 60)).getRGB());
            GlStateManager.color((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)0.3f);
            GL11.glVertex3d((double)(d + 0.5 * Math.cos((double)d4)), (double)d2, (double)(d3 + 0.5 * Math.sin((double)d4)));
            GL11.glVertex3d((double)(d + 0.5 * Math.cos((double)d5)), (double)d2, (double)(d3 + 0.5 * Math.sin((double)d5)));
            GlStateManager.color((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)0.0f);
            GL11.glVertex3d((double)(d + 0.5 * Math.cos((double)d4)), (double)(d2 + (bl ? -0.2 : 0.2)), (double)(d3 + 0.5 * Math.sin((double)d4)));
            GL11.glVertex3d((double)(d + 0.5 * Math.cos((double)d5)), (double)(d2 + (bl ? -0.2 : 0.2)), (double)(d3 + 0.5 * Math.sin((double)d5)));
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glShadeModel((int)7424);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    private void drawCircle(Entity entity, float f, float f2) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glShadeModel((int)7425);
        GL11.glLineWidth((float)1.0f);
        double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f - this.mc.getRenderManager().viewerPosX;
        double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f - this.mc.getRenderManager().viewerPosY + (double)f2;
        double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f - this.mc.getRenderManager().viewerPosZ;
        GL11.glBegin((int)3);
        for (int i = 0; i <= 180; ++i) {
            double d4 = (double)i * Math.PI * 2.0 / 180.0;
            Color color = new Color(HUD.getAstolfoColor((int)4000, (float)(i * 60)).getRGB());
            GlStateManager.color((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)1.0f);
            GL11.glVertex3d((double)(d + 0.5 * Math.cos((double)d4)), (double)d2, (double)(d3 + 0.5 * Math.sin((double)d4)));
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glShadeModel((int)7424);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public float[] getRotationFromPositionSlow(double d, double d2, double d3) {
        double d4 = d - Minecraft.getMinecraft().thePlayer.posX;
        double d5 = d2 - Minecraft.getMinecraft().thePlayer.posZ;
        double d6 = d3 - (this.mc.thePlayer.posY + (double)this.mc.thePlayer.getEyeHeight()) + 0.2;
        double d7 = MathHelper.sqrt_double((double)(d4 * d4 + d5 * d5));
        float f = (float)(Math.atan2((double)d5, (double)d4) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(-(Math.atan2((double)d6, (double)d7) * 180.0 / Math.PI));
        return new float[]{f, f2};
    }

    public float[] getRotationsToPos(double d, double d2, double d3) {
        double d4 = d - this.mc.thePlayer.posX;
        double d5 = d2 - this.mc.thePlayer.posZ;
        double d6 = d3;
        double d7 = MathHelper.sqrt_double((double)(d4 * d4 + d5 * d5));
        float f = (float)(Math.atan2((double)d5, (double)d4) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(-(Math.atan2((double)d6, (double)d7) * 180.0 / Math.PI));
        return new float[]{f, f2};
    }

    private boolean isAutismShopKeeperCheck(Entity entity) {
        IChatComponent iChatComponent = entity.getDisplayName();
        String string = iChatComponent.getFormattedText();
        iChatComponent.getUnformattedText();
        boolean bl = !string.substring(0, string.length() - 2).contains((CharSequence)"\u00a7");
        boolean bl2 = string.substring(string.length() - 2).contains((CharSequence)"\u00a7");
        return bl && bl2;
    }

    @EventHandler
    private void onUpdatePost(EventPostUpdate eventPostUpdate) {
        if (!((Boolean)onlySwordsTools.getValue()).booleanValue() || this.mc.thePlayer.getHeldItem().getItem() != null && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
            if (target != null) {
                if (((Boolean)autoBlockValue.getValue()).equals((Object)false) && this.hasSword((EntityPlayer)this.mc.thePlayer) && this.mc.thePlayer.isBlocking()) {
                    if (this.mc.thePlayer.swingProgressInt == -1) {
                        PacketUtils.sendPacket((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-1, -1, -1), EnumFacing.DOWN));
                    } else if (this.mc.thePlayer.swingProgressInt == 0) {
                        PacketUtils.sendPacket((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, this.mc.thePlayer.getHeldItem(), 0.0f, 0.0f, 0.0f));
                    }
                }
                if (this.ShouldAttack()) {
                    EventBus.getInstance().call((Event)new EventAttack((Entity)target, true));
                    if (this.mc.thePlayer.getFoodStats().getFoodLevel() > 6 && ((Boolean)keepsprintvalue.getValue()).booleanValue()) {
                        this.mc.thePlayer.sendQueue.getNetworkManager().sendPacket((Packet)new C0BPacketEntityAction((Entity)this.mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                    }
                    if (((Boolean)multi.getValue()).booleanValue()) {
                        int n = 0;
                        Iterator iterator = this.targetList.iterator();
                        while (iterator.hasNext() && n < ((Number)this.MAXT.getValue()).intValue()) {
                            Entity entity = (Entity)iterator.next();
                            if (!this.getEntityValid((EntityLivingBase)entity)) continue;
                            this.mc.thePlayer.swingItem();
                            this.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
                            ++n;
                        }
                    } else {
                        this.mc.thePlayer.swingItem();
                        this.mc.playerController.attackEntity((EntityPlayer)this.mc.thePlayer, (Entity)target);
                        if (this.mc.thePlayer.getFoodStats().getFoodLevel() > 6 && ((Boolean)keepsprintvalue.getValue()).booleanValue()) {
                            this.mc.thePlayer.sendQueue.getNetworkManager().sendPacket((Packet)new C0BPacketEntityAction((Entity)this.mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                        }
                        EventBus.getInstance().call((Event)new EventAttack((Entity)target, false));
                    }
                    if (EnchantmentHelper.getModifierForCreature((ItemStack)this.mc.thePlayer.getHeldItem(), (EnumCreatureAttribute)target.getCreatureAttribute()) > 0.0f) {
                        this.mc.thePlayer.onEnchantmentCritical((Entity)target);
                    }
                    if (!(!(this.mc.thePlayer.fallDistance > 0.0f) || this.mc.thePlayer.onGround || this.mc.thePlayer.isOnLadder() || this.mc.thePlayer.isInWater() || this.mc.thePlayer.isPotionActive(Potion.blindness) || this.mc.thePlayer.ridingEntity != null)) {
                        this.mc.thePlayer.onCriticalHit((Entity)target);
                    }
                    this.attacktimer.reset();
                }
            }
            if (this.ShouldAttack()) {
                if (((Boolean)autoBlockValue.getValue()).equals((Object)false) && blockTarget != null) {
                    this.mc.thePlayer.swingItem();
                }
                this.attacktimer.reset();
            }
            if (target != null && ((Boolean)autoBlockValue.getValue()).booleanValue()) {
                if (this.hasSword((EntityPlayer)this.mc.thePlayer) && !this.mc.thePlayer.isBlocking()) {
                    blocking = true;
                    if (this.mc.thePlayer.swingProgressInt == -1) {
                        PacketUtils.sendPacket((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-1, -1, -1), EnumFacing.DOWN));
                    } else if (this.mc.thePlayer.swingProgressInt == 0) {
                        PacketUtils.sendPacket((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, this.mc.thePlayer.getHeldItem(), 0.0f, 0.0f, 0.0f));
                    }
                }
                blocking = true;
            } else {
                blocking = false;
            }
        }
    }

    private boolean notInFov(Entity entity) {
        return !(Math.abs((float)RotationUtil.getYawDifference((float)this.mc.thePlayer.rotationYaw, (double)entity.posX, (double)entity.posY, (double)entity.posZ)) <= ((Number)this.fovValue.getValue()).floatValue());
    }

    public static EntityLivingBase getBlockTarget() {
        return blockTarget;
    }

    public float[] getRotations(EntityLivingBase entityLivingBase) {
        double d = entityLivingBase.posX;
        double d2 = entityLivingBase.posZ;
        double d3 = entityLivingBase.posY;
        return this.getRotationFromPositionSlow(d, d2, d3);
    }

    public static double randomDouble(double d, double d2) {
        return ThreadLocalRandom.current().nextDouble(d, d2);
    }

    private void targetsSort() {
        if (this.Priority.getValue() == priority.Armor) {
            this.targetList.sort(Comparator.comparingInt(KillAura::lambda$targetsSort$5));
        }
        if (this.Priority.getValue() == priority.Range) {
            this.targetList.sort(this::lambda$targetsSort$6);
        }
        if (this.Priority.getValue() == priority.Fov) {
            this.targetList.sort(Comparator.comparingDouble(this::lambda$targetsSort$7));
        }
        if (this.Priority.getValue() == priority.Angle) {
            this.targetList.sort(this::lambda$targetsSort$8);
        }
        if (this.Priority.getValue() == priority.Health) {
            this.targetList.sort(Comparator.comparingDouble(EntityLivingBase::getHealth));
        }
    }

    public float[] lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII(EntityLivingBase entityLivingBase) {
        double d;
        double d2 = entityLivingBase.posX;
        double d3 = entityLivingBase.posZ;
        if (entityLivingBase instanceof EntityEnderman) {
            d = entityLivingBase.posY - this.mc.thePlayer.posY;
        } else {
            double d4 = (double)this.mc.thePlayer.getEyeHeight() - 1.65 - KillAura.SAOGANGONYOUSAOGANGONYOU(0.0, 10.0) * 0.04;
            d = entityLivingBase.posY + (double)entityLivingBase.getEyeHeight() - 1.5 < this.mc.thePlayer.posY + d4 ? entityLivingBase.posY + (double)entityLivingBase.getEyeHeight() - this.mc.thePlayer.posY + ((double)this.mc.thePlayer.getEyeHeight() - 3.0) : (entityLivingBase.posY - 1.5 > this.mc.thePlayer.posY + d4 ? entityLivingBase.posY - 3.0 - this.mc.thePlayer.posY + (double)this.mc.thePlayer.getEyeHeight() : d4);
        }
        return this.getRotationsToPos(d2, d3, d);
    }

    public float[] rotationsToEntity(EntityLivingBase entityLivingBase) {
        Vec3d vec3d = new Vec3d(this.mc.thePlayer.posX + this.mc.thePlayer.motionX, this.mc.thePlayer.posY + (double)this.mc.thePlayer.getEyeHeight() + this.mc.thePlayer.motionY, this.mc.thePlayer.posZ + this.mc.thePlayer.motionZ);
        Vec3d vec3d2 = new Vec3d(0.0, entityLivingBase.posY + (double)entityLivingBase.getEyeHeight(), 0.0);
        float f = 0.0f;
        while (f < entityLivingBase.getEyeHeight()) {
            Vec3d vec3d3 = new Vec3d(0.0, entityLivingBase.posY + (double)f + entityLivingBase.posY - entityLivingBase.prevPosY, 0.0);
            if (vec3d3.distanceTo(vec3d) < vec3d2.distanceTo(vec3d)) {
                vec3d2 = vec3d3;
            }
            f = (float)((double)f + 0.05);
        }
        double d = Math.abs((double)(entityLivingBase.getEntityBoundingBox().maxX - entityLivingBase.getEntityBoundingBox().minX)) / 2.0;
        double d2 = Math.abs((double)(entityLivingBase.getEntityBoundingBox().maxZ - entityLivingBase.getEntityBoundingBox().minZ)) / 2.0;
        double d3 = entityLivingBase.posX - vec3d.xCoord;
        double d4 = vec3d2.yCoord - vec3d.yCoord;
        double d5 = entityLivingBase.posZ - vec3d.zCoord;
        return this.applyMouseSensFix((float)Math.toDegrees((double)Math.atan2((double)d5, (double)d3)) - 90.0f, (float)(-Math.toDegrees((double)Math.atan2((double)d4, (double)Math.hypot((double)d3, (double)d5)))));
    }

    private boolean getEntityValidBlock(EntityLivingBase entityLivingBase) {
        block12: {
            block11: {
                Client.getModuleManager();
                Teams teams = (Teams)ModuleManager.getModuleByClass(Teams.class);
                Client.getModuleManager();
                AntiBot antiBot = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
                if (!this.mc.thePlayer.isEntityAlive() || this.mc.thePlayer.isPlayerSleeping() || this.mc.thePlayer.isDead || this.mc.thePlayer.getHealth() <= 0.0f) break block11;
                if (!Teams.isOnSameTeam((EntityLivingBase)entityLivingBase) && !((double)this.mc.thePlayer.getDistanceToEntity((Entity)entityLivingBase) >= (double)((Number)this.attackRangeValue.getValue()).floatValue()) && entityLivingBase.isEntityAlive() && !entityLivingBase.isDead && !(entityLivingBase.getHealth() <= 0.0f) && !(entityLivingBase instanceof EntityArmorStand) && !antiBot.isBot(entityLivingBase) && !this.isAutismShopKeeperCheck((Entity)entityLivingBase) && !this.notInFov((Entity)entityLivingBase) && entityLivingBase != this.mc.thePlayer) break block12;
            }
            return false;
        }
        if (entityLivingBase instanceof EntityPlayer) {
            EntityPlayer entityPlayer = (EntityPlayer)entityLivingBase;
            if (FriendManager.isFriend((String)entityPlayer.getName())) {
                return false;
            }
            if (!((Boolean)playerValue.getValue()).booleanValue()) {
                return false;
            }
            if (entityPlayer.isPlayerSleeping()) {
                return false;
            }
            if (entityPlayer.isPotionActive(Potion.invisibility) && !((Boolean)invisibleValue.getValue()).booleanValue()) {
                return false;
            }
        }
        if (entityLivingBase instanceof EntityAnimal) {
            return (Boolean)animalValue.getValue();
        }
        if (entityLivingBase instanceof EntityMob) {
            return (Boolean)monsterValue.getValue();
        }
        if (entityLivingBase instanceof EntityVillager || entityLivingBase instanceof EntityIronGolem || entityLivingBase instanceof EntitySnowman) {
            return (Boolean)neutralValue.getValue();
        }
        return true;
    }

    private double lambda$onUpdate$3(EntityLivingBase entityLivingBase) {
        return RotationUtils.getDistanceBetweenAngles((float)this.mc.thePlayer.rotationPitch, (float)RotationUtils.getNeededRotations((Entity)entityLivingBase)[0]);
    }

    public static float random(float f, float f2) {
        Random random = new Random();
        float f3 = f2 - f;
        float f4 = random.nextFloat() * f3;
        float f5 = f4 + f;
        return f5;
    }

    public void onEnable() {
        super.onEnable();
        this.targetList.clear();
        target = null;
        blockTarget = null;
        yaw = this.mc.thePlayer != null ? this.mc.thePlayer.rotationYaw : 0.0f;
        pitch = this.mc.thePlayer != null ? this.mc.thePlayer.rotationPitch : 0.0f;
        this.blockPreventFlagTimer.reset();
        this.index = 0;
        this.switchTimer.reset();
        this.RotTimer.reset();
    }

    private float[] getRotationsToEnt(Entity entity) {
        double d = entity.posX - this.mc.thePlayer.posX;
        double d2 = entity.posY + (double)entity.height - (this.mc.thePlayer.posY + (double)this.mc.thePlayer.height) - 0.9;
        double d3 = entity.posZ - this.mc.thePlayer.posZ;
        float f = (float)(Math.atan2((double)d3, (double)d) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(Math.atan2((double)d2, (double)this.mc.thePlayer.getDistanceToEntity(entity)) * 180.0 / Math.PI);
        float f3 = this.mc.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float((float)(f - this.mc.thePlayer.rotationYaw));
        float f4 = this.mc.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float((float)(f2 - this.mc.thePlayer.rotationPitch));
        return new float[]{f3, -MathHelper.clamp_float((float)f4, (float)-90.0f, (float)90.0f)};
    }
}
