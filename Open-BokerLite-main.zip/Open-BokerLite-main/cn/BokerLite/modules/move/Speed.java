package cn.BokerLite.modules.move;

import cn.BokerLite.gui.clickgui.ClickGui;
import cn.BokerLite.modules.value.Numbers;
import cn.BokerLite.modules.value.Option;
import cn.BokerLite.utils.MoveUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.potion.Potion;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import cn.BokerLite.api.event.PacketEvent;
import cn.BokerLite.modules.Module;
import cn.BokerLite.modules.ModuleType;
import cn.BokerLite.modules.value.Mode;
import cn.BokerLite.utils.movement.MovementUtils;
import cn.BokerLite.utils.timer.TimerUtil;

import java.util.Objects;

import static cn.BokerLite.Client.getTimer;

public class Speed extends Module {
    public static double movementSpeed;
    private final Mode<Enum<SpeedMode>> mode = new Mode<>("Mode", "mode", SpeedMode.values(), SpeedMode.FastHop);
    public TimerUtil timer = new TimerUtil();
    private final Option<Boolean> Timerb = new Option<>("Timer","", "Timer",false);
    private final Numbers timerv = new Numbers("TimerSpeed", "Timer速度", "TimerSpeed", 1.2, 0.0, 3.0, 0.1);
    boolean antiCheatDetecting;
    private int i;
    private boolean wasTimerFastYport = false;
    private boolean wasTimerVulcanHop = false;
    private int ticks = 0;

    public Speed() {
        super("Speed", "速度", Keyboard.KEY_NONE, ModuleType.Movement, "Make you move quickly",ModuleType.SubCategory.MOVEMENT_MAIN);
    }

    public static double getNormalSpeedEffect() {
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            return mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }

        return 0;
    }

    public static void setSpeed(double speed) {
        mc.thePlayer.motionX = -Math.sin(getDirection()) * speed;
        mc.thePlayer.motionZ = Math.cos(getDirection()) * speed;
    }

    public static float getDirection() {
        float yaw = mc.thePlayer.rotationYaw;
        if (mc.thePlayer.movementInput.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        if (mc.thePlayer.movementInput.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (mc.thePlayer.movementInput.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (mc.thePlayer.movementInput.moveStrafe > 0.0f) {
            yaw -= 90.0f * forward;
        }
        if (mc.thePlayer.movementInput.moveStrafe < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw * ((float) Math.PI / 180);
    }

    @Override
    public void disable() {
        try {
            Objects.requireNonNull(getTimer()).timerSpeed = 1.0f;
        } catch (NullPointerException e) {
            // fuck
        }
    }

    @Override
    public void enable() {
        antiCheatDetecting = false;
    }

    public static net.minecraft.util.Timer getTimer() {
        return ObfuscationReflectionHelper.getPrivateValue(Minecraft.class, Minecraft.getMinecraft(), "timer", "field_71428_T");
    }

    public static void resetTimer() {
        try {
            getTimer().timerSpeed = 1.0F;
        } catch (NullPointerException ignored) {
        }
    }

    @SubscribeEvent
    public void onTimer(TickEvent.PlayerTickEvent event) {
        if (!(mc.currentScreen instanceof ClickGui)&& Timerb.getValue()) {
            getTimer().timerSpeed = timerv.getValue().floatValue();
        } else {
            resetTimer();
        }

    }




    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent event) {
        this.setSuffix(mode.getValue().toString());

        if (mode.getValue() == SpeedMode.Boosting) {
            if (this.i == 0) {
                this.i = mc.thePlayer.ticksExisted;
            }
            try {
                Objects.requireNonNull(getTimer()).timerSpeed = (float) 2.0;
                if (this.i == mc.thePlayer.ticksExisted - 15.0) {
                    getTimer().timerSpeed = 1.0f;
                    this.disable();
                }
            } catch (NullPointerException e) {
                //
            }
        }
        if (mode.getValue() == SpeedMode.FastHop) {
            if (!mc.thePlayer.isCollidedHorizontally && mc.thePlayer.moveForward > 0 && mc.thePlayer.onGround) {
                mc.thePlayer.setSprinting(true);
                mc.thePlayer.jump();
            }
        } else if (mode.getValue() == SpeedMode.SlowHop) {
            if (!mc.thePlayer.isCollidedHorizontally && mc.thePlayer.moveForward > 0 && mc.thePlayer.onGround) {
                mc.thePlayer.jump();
                setSpeed(0.26 + (getNormalSpeedEffect() * 2));
            } else {
                setSpeed(0);
            }
            movementSpeed = 0.26;
        } else if (mode.getValue() == SpeedMode.BunnyHop) {
            if (isToJump() && Minecraft.getMinecraft().thePlayer.moveForward != 0 && (Minecraft.getMinecraft().thePlayer.posY % 1 == 0))
                Minecraft.getMinecraft().thePlayer.jump();
        } else if (mode.getValue()==SpeedMode.FastYport) {
            ticks++;
            if (wasTimerFastYport) {
                getTimer().timerSpeed = 1.00f;
                wasTimerFastYport = false;
            }
            mc.thePlayer.jumpMovementFactor = 0.0245f;
            if (!mc.thePlayer.onGround && ticks > 3 && mc.thePlayer.motionY > 0) {
                mc.thePlayer.motionY = -0.27;
            }

            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(),mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump));
            if (MovementUtils.getSpeed() < 0.215f && !mc.thePlayer.onGround) {
                MovementUtils.strafe(0.215f);
            }
            if (mc.thePlayer.onGround && MovementUtils.isMoving()) {
                ticks = 0;
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(),false);
                mc.thePlayer.jump();
                if (!mc.thePlayer.isAirBorne) {
                    return ;//Prevent flag with Fly
                }
                getTimer().timerSpeed = 1.4f;
                wasTimerFastYport = true;
                if(MovementUtils.getSpeed() < 0.48f) {
                    MovementUtils.strafe(0.48f);
                }else{
                    MovementUtils.strafe((float) (MovementUtils.getSpeed()*0.985));
                }
            }else if (!MovementUtils.isMoving()) {
                getTimer().timerSpeed = 1.00f;
                mc.thePlayer.motionX = 0.0;
                mc.thePlayer.motionZ = 0.0;
            }
        } else if (mode.getValue() == SpeedMode.Hypixel) {

            if (wasTimerVulcanHop) {
                getTimer().timerSpeed = 1.00f;
                wasTimerVulcanHop = false;
            }
            if (Math.abs(mc.thePlayer.movementInput.moveStrafe) < 0.1f) {
                mc.thePlayer.jumpMovementFactor = 0.026499f;
            }else {
                mc.thePlayer.jumpMovementFactor = 0.0244f;
            }
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(),mc.gameSettings.isKeyDown(mc.gameSettings.keyBindJump));

            if (MovementUtils.getSpeed() < 0.215f && !mc.thePlayer.onGround) {
                if (TargetStrafe.canStrafe()) {
                    TargetStrafe.strafe( 0.215f);
                } else {
                    MovementUtils.strafe(0.215f);
                }

            }
            if (mc.thePlayer.onGround && MovementUtils.isMoving()) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(),false);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), true);

                getTimer().timerSpeed = 1.25f;
                wasTimerVulcanHop = true;

                if(MovementUtils.getSpeed() < 0.5f) {

                }
            }else if (!MovementUtils.isMoving()) {
                getTimer().timerSpeed = 1.00f;
                mc.thePlayer.motionX = 0.0;
                mc.thePlayer.motionZ = 0.0;
            }
        }
    }

    public boolean isToJump() {
        return mc.thePlayer != null && !mc.thePlayer.isInWater() && !mc.thePlayer.isOnLadder();
    }

    enum SpeedMode {
        FastHop,
        Boosting,
        BunnyHop,
        SlowHop,
        FastYport,

      Hypixel;
    }

}