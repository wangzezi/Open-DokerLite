package cn.BokerLite.modules.Player;

import com.google.common.collect.Multimap;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import cn.BokerLite.Client;
import cn.BokerLite.modules.Module;
import cn.BokerLite.modules.ModuleType;
import cn.BokerLite.modules.value.Numbers;
import cn.BokerLite.modules.value.Option;
import cn.BokerLite.utils.timer.TimerUtil;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;

public class InvCleaner extends Module {
    public static final Random RANDOM = new Random();
    public boolean hasNoItems;
    public final TimerUtil timer = new TimerUtil();
    public Option<Boolean> openInv = new Option<>("OpenInv", "仅打开背包", "OpenInv", true);
    private final Numbers delay = new Numbers("Delay", "间隔", "Delay", 50.0, 0.0, 1000.0, 10.0);
    private final int[] boots = new int[]{313, 309, 317, 305, 301};
    private final int[] chestplate = new int[] { 311, 307, 315, 303, 299 };
    private final int[] helmet = new int[] { 310, 306, 314, 302, 298 };
    private final int[] leggings = new int[] { 312, 308, 316, 304, 300 };
    private int slot = 5;
    private double enchantmentValue = -1.0;
    private int item = -1;

    public InvCleaner() {
        super("InvCleaner", "背包清理",Keyboard.KEY_NONE, ModuleType.Player, " Auto Management inv",ModuleType.SubCategory.PLayer_Player);
    }

    @Override
    public void enable() {
        this.hasNoItems = false;
    }

    @SubscribeEvent
    public void onTick(TickEvent event) {
        if (Client.nullCheck())
            return;
        if (!this.state)
            return;
        if (mc.thePlayer.isUsingItem()) {
            return;
        }
        if (mc.thePlayer.ticksExisted % 2 == 0 && RANDOM.nextInt(2) == 0 && (!this.openInv.getValue() || mc.currentScreen instanceof GuiInventory && this.openInv.getValue()) && this.timer.hasReached(this.delay.getValue())) {
            CopyOnWriteArrayList<Integer> uselessItems = new CopyOnWriteArrayList<>();
            int o = 0;
            while (o < 45) {
                if (mc.thePlayer.inventoryContainer.getSlot(o).getHasStack()) {
                    ItemStack item = mc.thePlayer.inventoryContainer.getSlot(o).getStack();
                    if (mc.thePlayer.inventory.armorItemInSlot(0) != item && mc.thePlayer.inventory.armorItemInSlot(1) != item && mc.thePlayer.inventory.armorItemInSlot(2) != item && mc.thePlayer.inventory.armorItemInSlot(3) != item) {
                        if (item != null && item.getItem() != null && Item.getIdFromItem(item.getItem()) != 0 && !this.stackIsUseful(o)) {
                            uselessItems.add(o);
                        }
                        this.hasNoItems = true;
                    }
                }
                ++o;
            }
            if (!uselessItems.isEmpty()) {
                if (mc.thePlayer.capabilities.isCreativeMode
                        || mc.thePlayer.openContainer != null && mc.thePlayer.openContainer.windowId != 0) {
                    return;
                }
                if (this.timer.hasReached(this.delay.getValue() + (double) new Random().nextInt(4))) {
                    this.enchantmentValue = -1.0;
                    this.item = -1;
                    int i = 9;
                    while (i < 45) {
                        if (mc.thePlayer.inventoryContainer.getSlot(i).getStack() != null
                                && this.canEquip(mc.thePlayer.inventoryContainer.getSlot(i).getStack()) != -1
                                && this.canEquip(mc.thePlayer.inventoryContainer.getSlot(i).getStack()) == this.slot) {
                            this.change(this.slot, i);
                        }
                        ++i;
                    }
                    if (this.item != -1) {
                        if (mc.thePlayer.inventoryContainer.getSlot(this.item).getStack() != null) {
                            mc.playerController.windowClick(0, this.slot, 0, 1, mc.thePlayer);
                        }
                        mc.playerController.windowClick(0, this.item, 0, 1, mc.thePlayer);
                    }
                    this.slot = this.slot == 8 ? 5 : ++this.slot;
                    this.timer.reset();
                }
                mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, uselessItems.get(0), 1, 4, mc.thePlayer);
                uselessItems.remove(0);
                this.timer.reset();
            }
        }
    }


    private int canEquip(ItemStack stack) {
        int id;
        int[] arrn = this.boots;
        int n = arrn.length;
        int n2 = 0;
        while (n2 < n) {
            id = arrn[n2];
            stack.getItem();
            if (Item.getIdFromItem(stack.getItem()) == id) {
                return 8;
            }
            ++n2;
        }
        arrn = this.leggings;
        n = arrn.length;
        n2 = 0;
        while (n2 < n) {
            id = arrn[n2];
            stack.getItem();
            if (Item.getIdFromItem(stack.getItem()) == id) {
                return 7;
            }
            ++n2;
        }
        arrn = this.chestplate;
        n = arrn.length;
        n2 = 0;
        while (n2 < n) {
            id = arrn[n2];
            stack.getItem();
            if (Item.getIdFromItem(stack.getItem()) == id) {
                return 6;
            }
            ++n2;
        }
        arrn = this.helmet;
        n = arrn.length;
        n2 = 0;
        while (n2 < n) {
            id = arrn[n2];
            stack.getItem();
            if (Item.getIdFromItem(stack.getItem()) == id) {
                return 5;
            }
            ++n2;
        }
        return -1;
    }

    private void change(int numy, int i) {
        double protectionValue = this.enchantmentValue == -1.0
                ? (mc.thePlayer.inventoryContainer.getSlot(numy).getStack() != null
                ? this.getProtValue(mc.thePlayer.inventoryContainer.getSlot(numy).getStack())
                : this.enchantmentValue)
                : this.enchantmentValue;
        if (protectionValue <= this.getProtValue(mc.thePlayer.inventoryContainer.getSlot(i).getStack())) {
            if (protectionValue == this.getProtValue(mc.thePlayer.inventoryContainer.getSlot(i).getStack())) {
                int newD;
                int currentD = mc.thePlayer.inventoryContainer.getSlot(numy).getStack() != null
                        ? mc.thePlayer.inventoryContainer.getSlot(numy).getStack().getItemDamage()
                        : 999;
                newD = mc.thePlayer.inventoryContainer.getSlot(i).getStack() != null
                        ? mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItemDamage()
                        : 500;
                if (newD <= currentD && newD != currentD) {
                    this.item = i;
                    this.enchantmentValue = this
                            .getProtValue(mc.thePlayer.inventoryContainer.getSlot(i).getStack());
                }
            } else {
                this.item = i;
                this.enchantmentValue = this.getProtValue(mc.thePlayer.inventoryContainer.getSlot(i).getStack());
            }
        }
    }

    private double getProtValue(ItemStack stack) {
        if (stack != null) {
            return (double) ((ItemArmor) stack.getItem()).damageReduceAmount
                    + (double) ((100 - ((ItemArmor) stack.getItem()).damageReduceAmount * 4)
                    * EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, stack) * 4)
                    * 0.0075;
        }
        return 0.0;
    }

    public boolean stackIsUseful(int i) {
        int o;
        ItemStack item;
        boolean hasAlreadyOrBetter;
        ItemStack itemStack;
        itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
        hasAlreadyOrBetter = false;
        if (itemStack.getItem() instanceof ItemSword || itemStack.getItem() instanceof ItemPickaxe || itemStack.getItem() instanceof ItemAxe) {
            o = 0;
            try {
                while (o < 45) {
                    if (o != i && mc.thePlayer.inventoryContainer.getSlot(o).getHasStack() && ((item = mc.thePlayer.inventoryContainer.getSlot(o).getStack()) != null && item.getItem() instanceof ItemSword || Objects.requireNonNull(item).getItem() instanceof ItemAxe || item.getItem() instanceof ItemPickaxe)) {
                        float damageFound = this.getItemDamage(itemStack);
                        float damageCurrent = this.getItemDamage(item);
                        if (damageCurrent + EnchantmentHelper.getModifierForCreature(item, EnumCreatureAttribute.UNDEFINED) > damageFound + EnchantmentHelper.getModifierForCreature(itemStack, EnumCreatureAttribute.UNDEFINED)) {
                            hasAlreadyOrBetter = true;
                            break;
                        }
                    }
                    ++o;
                }
            }catch (Exception ignored){}
        } else if (itemStack.getItem() instanceof ItemArmor) {
            o = 0;
            while (o < 45) {
                if (i != o && mc.thePlayer.inventoryContainer.getSlot(o).getHasStack() && (item = mc.thePlayer.inventoryContainer.getSlot(o).getStack()) != null && item.getItem() instanceof ItemArmor) {
                    List<Integer> helmet = Arrays.asList(298, 314, 302, 306, 310);
                    List<Integer> chestplate = Arrays.asList(299, 315, 303, 307, 311);
                    List<Integer> leggings = Arrays.asList(300, 316, 304, 308, 312);
                    List<Integer> boots = Arrays.asList(301, 317, 305, 309, 313);
                    if (helmet.contains(Item.getIdFromItem(item.getItem())) && helmet.contains(Item.getIdFromItem(itemStack.getItem()))) {
                        if (helmet.indexOf(Item.getIdFromItem(itemStack.getItem())) < helmet.indexOf(Item.getIdFromItem(item.getItem()))) {
                            hasAlreadyOrBetter = true;
                            break;
                        }
                    } else if (chestplate.contains(Item.getIdFromItem(item.getItem())) && chestplate.contains(Item.getIdFromItem(itemStack.getItem()))) {
                        if (chestplate.indexOf(Item.getIdFromItem(itemStack.getItem())) < chestplate.indexOf(Item.getIdFromItem(item.getItem()))) {
                            hasAlreadyOrBetter = true;
                            break;
                        }
                    } else if (leggings.contains(Item.getIdFromItem(item.getItem())) && leggings.contains(Item.getIdFromItem(itemStack.getItem()))) {
                        if (leggings.indexOf(Item.getIdFromItem(itemStack.getItem())) < leggings.indexOf(Item.getIdFromItem(item.getItem()))) {
                            hasAlreadyOrBetter = true;
                            break;
                        }
                    } else if (boots.contains(Item.getIdFromItem(item.getItem())) && boots.contains(Item.getIdFromItem(itemStack.getItem())) && boots.indexOf(Item.getIdFromItem(itemStack.getItem())) < boots.indexOf(Item.getIdFromItem(item.getItem()))) {
                        hasAlreadyOrBetter = true;
                        break;
                    }
                }
                ++o;
            }
        }
        o = 0;
        while (o < 45) {
            if (i != o && mc.thePlayer.inventoryContainer.getSlot(o).getHasStack() && (item = mc.thePlayer.inventoryContainer.getSlot(o).getStack()) != null && (item.getItem() instanceof ItemSword || item.getItem() instanceof ItemAxe || item.getItem() instanceof ItemBow || item.getItem() instanceof ItemFishingRod || item.getItem() instanceof ItemArmor || item.getItem() instanceof ItemAxe || item.getItem() instanceof ItemPickaxe || Item.getIdFromItem(item.getItem()) == 346)) {
                item.getItem();
                if (Item.getIdFromItem(itemStack.getItem()) == Item.getIdFromItem(item.getItem())) {
                    hasAlreadyOrBetter = true;
                    break;
                }
            }
            ++o;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 367) {
            return false;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 30) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 259) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 262) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 264) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 265) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 346) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 384) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 345) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 296) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 336) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 266) {
            return true;
        }
        if (Item.getIdFromItem(itemStack.getItem()) == 280) {
            return true;
        }
        if (itemStack.hasDisplayName()) {
            return true;
        }
        if (hasAlreadyOrBetter) {
            return false;
        }
        if (itemStack.getItem() instanceof ItemArmor) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemAxe) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemBow) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemSword) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemPotion) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemFlintAndSteel) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemEnderPearl) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemBlock) {
            return true;
        }
        if (itemStack.getItem() instanceof ItemFood) {
            return true;
        }
        return itemStack.getItem() instanceof ItemPickaxe;
    }

    public float getItemDamage(ItemStack itemStack) {
        Iterator<Entry<String, AttributeModifier>> iterator;
        Multimap<String, AttributeModifier> multimap = itemStack.getAttributeModifiers();
        if (!multimap.isEmpty() && (iterator = multimap.entries().iterator()).hasNext()) {
            Entry<String, AttributeModifier> entry = iterator.next();
            AttributeModifier attributeModifier = entry.getValue();
            double damage = attributeModifier.getOperation() != 1 && attributeModifier.getOperation() != 2 ? attributeModifier.getAmount() : attributeModifier.getAmount() * 100.0;
            if (attributeModifier.getAmount() > 1.0) {
                return 1.0f + (float)damage;
            }
            return 1.0f;
        }
        return 1.0f;
    }

}