package cn.BokerLite.modules.Player;

import cn.BokerLite.api.EventHandler;
import cn.BokerLite.api.event.EventPacketSend;
import cn.BokerLite.modules.Module;
import cn.BokerLite.modules.ModuleType;
import cn.BokerLite.modules.value.Mode;
import cn.BokerLite.modules.value.Numbers;
import cn.BokerLite.utils.packet.PacketUtil;
import cn.BokerLite.utils.reflect.ReflectionUtil;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class SpeedMine extends Module {

    public static Numbers speed = new Numbers("Speed","Speed","Speed", 1.4D, 1.0D, 2.0D, 0.1D);
    public BlockPos blockPos;
    public EnumFacing facing;
    private boolean bzs = false;
    private float bzx = 0.0F;

    public SpeedMine() {
        super("SpeedMine", "快速挖掘", Keyboard.KEY_NONE, ModuleType.Player, "Make you dig faster",ModuleType.SubCategory.PLayer_Player);
     //   this.modeValue = new Mode<modeEnums>("Mode", "Mode", modeEnums.values(), modeEnums.Packet);
     //   this.Speed = new Numbers("SpeedMine", "SpeedMine","SpeedMine",1.4, 0.0, 3.0, 0.1);
    }


    @EventHandler
    public void onDamageBlock(EventPacketSend event) {
        if (event.getPacket() instanceof C07PacketPlayerDigging && !mc.playerController.extendedReach() && mc.playerController != null) {
            C07PacketPlayerDigging c07PacketPlayerDigging = (C07PacketPlayerDigging) event.getPacket();
            if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                bzs = true;
                blockPos = c07PacketPlayerDigging.getPosition();
                facing = c07PacketPlayerDigging.getFacing();
                bzx = 0;
            } else if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK || c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                bzs = false;
                blockPos = null;
                facing = null;
            }
        }
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent event) {// curBlockDamageMP : field_78770_f
        if (((float) ReflectionUtil.getFieldValue(mc.playerController, "curBlockDamageMP", "field_78770_f")) >= speed.getValue().floatValue()) {
            ReflectionUtil.setFieldValue(mc.playerController, 1, "curBlockDamageMP", "field_78770_f");
            boolean item = mc.thePlayer.getCurrentEquippedItem() == null;
            mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 20, item ? 1 : 0));
        }
        if (mc.playerController.extendedReach()) {// field_78781_i
            ReflectionUtil.setFieldValue(mc.playerController, 0, "blockHitDelay", "field_78781_i");
        } else {
            if (bzs) {
                Block block = mc.theWorld.getBlockState(blockPos).getBlock();
                bzx = (float) bzx + (float) (block.getPlayerRelativeBlockHardness(mc.thePlayer, mc.theWorld, blockPos) * speed.getValue().floatValue());
                if (bzx >= 1.0F) {
                    mc.theWorld.setBlockState(blockPos, Blocks.air.getDefaultState(), 11);
                    PacketUtil.sendPacketWithoutEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, blockPos, facing));
                    bzx = 0.0F;
                    bzs = false;
                }
            }
        }
    }


}