package cn.BokerLite.modules.Player.disabler;

import cn.BokerLite.api.EventHandler;
import cn.BokerLite.api.event.EventPacketRecieve;
import cn.BokerLite.modules.Module;
import cn.BokerLite.modules.ModuleType;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public class HypixelTimer extends Module {
    public HypixelTimer() {
        super("Disabler", "Watchdog关闭器", Keyboard.KEY_NONE, ModuleType.Player, "Timer bypassing helper",ModuleType.SubCategory.PLayer_Player);
    }

    @Override
    public void enable() {
        keepAlivePackets.clear();
        transactionPackets.clear();
        super.enable();
    }

    @Override
    public void disable() {
        keepAlivePackets.clear();
        transactionPackets.clear();
        super.disable();
    }

    private final List<C00PacketKeepAlive> keepAlivePackets = new ArrayList<>();

    private final Timer timer = new Timer();

    private final List<C0FPacketConfirmTransaction> transactionPackets = new ArrayList<>();

    @EventHandler
    public void onPacket(EventPacketRecieve event){
        if (mc.isSingleplayer())return;
        final Packet<?> packet = event.getPacket();
        if (packet instanceof C00PacketKeepAlive && packet != keepAlivePackets.get(keepAlivePackets.size() - 1)) {
            keepAlivePackets.add((C00PacketKeepAlive) packet);
            event.setCancelled(true);
        }
        if (packet instanceof C0FPacketConfirmTransaction && packet != transactionPackets.get(transactionPackets.size() - 1)) {
            transactionPackets.add((C0FPacketConfirmTransaction) packet);
            event.setCancelled(true);
        }
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent event){
        if (mc.isSingleplayer())return;
        if (keepAlivePackets.size() > 0 && transactionPackets.size() > 0) {
            if (timer.delay(3000)) {
                mc.getNetHandler().addToSendQueue(keepAlivePackets.get(keepAlivePackets.size() - 1));
                mc.getNetHandler().addToSendQueue(transactionPackets.get(transactionPackets.size() - 1));
                keepAlivePackets.clear();
                transactionPackets.clear();
                timer.reset();
            }
        }
    }
}
