package cn.BokerLite.irc;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pi.yalan.packet.IServerPacketHandler;
import pi.yalan.packet.server.*;

import java.util.Random;

public class ServerPacketHandler implements IServerPacketHandler {
    private final Logger log = LogManager.getLogger(ServerPacketHandler.class);
    private final Auth instance;

    public ServerPacketHandler(Auth instance) {
        this.instance = instance;
    }

    @Override
    public void processClose(SClosePacket packet) {
        if (Minecraft.getMinecraft().thePlayer != null) Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("服务器已关闭!"));

        log.info("IRC server closed");
    }

    @Override
    public void processKick(SKickPacket packet) {
        if (Minecraft.getMinecraft().thePlayer != null) Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("You are Kick! Because:" + packet.getReason()));
        Runtime.getRuntime().exit(new Random().nextInt(123123));

        log.info("Kicked reason:" + packet.getReason());
    }

    @Override
    public void processMessage(SMessagePacket packet) {
        if (Minecraft.getMinecraft().thePlayer != null) Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(packet.getMessage()));

        log.info("IRC Message:" + packet.getMessage());
    }

    @Override
    public void processAuthResult(SAuthResultPacket packet) {
        Auth.Instance.memory.put(Auth.ADDRESS_AUTH_RESULT,packet.getResult());
    }

    @Override
    public void processRegisterResult(SRegisterResultPacket packet) {
        Auth.Instance.memory.put(Auth.ADDRESS_REGISTER_RESULT,packet.getResult());
    }
}
