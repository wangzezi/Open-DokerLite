/*
 * Decompiled with CFR 0_132.
 */
package cn.BokerLite.api;

public class Type {
	public static final byte PRE = 0;
	public static final byte POST = 1;
	public static final byte OUTGOING = 2;
	public static final byte INCOMING = 3;
}
