package cn.BokerLite.api.enums;

public enum ACType {
    Player,
    None, Module
}
