package cn.BokerLite.api.enums;

public enum Type {
    Public,
    Beta,
    Dev,
    Private
}
