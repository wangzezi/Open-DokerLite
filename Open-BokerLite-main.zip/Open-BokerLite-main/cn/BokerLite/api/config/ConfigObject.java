package cn.BokerLite.api.config;

@SuppressWarnings("unused")
public class
ConfigObject {
    public String name;
    public String uuid;
    public String date;
    public String data;

    public ConfigObject(String name, String uuid, String date, String data) {
        this.name = name;
        this.uuid = uuid;
        this.date = date;
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String newDate) {
        this.date = newDate;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
