package cn.BokerLite.api.config;

import org.lwjgl.input.Keyboard;
import cn.BokerLite.modules.Module;
import cn.BokerLite.modules.ModuleManager;
import cn.BokerLite.modules.value.Mode;
import cn.BokerLite.modules.value.Numbers;
import cn.BokerLite.modules.value.Option;
import cn.BokerLite.modules.value.Value;

import java.util.Iterator;

public class ConfigUtils {
    @SuppressWarnings("rawtypes")
    public static String getConfigStr() {
        String result = "";
        String content = "";
        Module m;
        for (Iterator<Module> var4 = ModuleManager.getModules().iterator(); var4.hasNext(); content = content + String.format("%s:%s%s", m.getName(), Keyboard.getKeyName(m.getKey()), "\n")) {
            m = var4.next();
        }
        result = result + content + "\n============\n";
        StringBuilder values = new StringBuilder();
        for (Module module : ModuleManager.getModules()) {
            for (Value v : module.getValues()) {
                values.append(String.format("%s:%s:%s%s", module.getName(), v.getName(), v.getValue(), "\n"));
            }
        }
        result = result + values + "\n============\n";
        StringBuilder enabled = new StringBuilder();
        for (Module modules : ModuleManager.getModules()) {
            if (!modules.getState()) continue;
            enabled.append(String.format("%s%s", modules.getName(), "\n"));
        }
        result = result + enabled;
        return result;
    }

    public static void readSettings(String cfg, boolean loadMod) {
        String[] Splited = cfg.split("\n============\n");
        if (loadMod) {
//            ArrayList<String> enabled = (ArrayList<String>) FileManager.read("mod.cfg");
            for (String v : Splited[2].split("\n")) {
                Module m = ModuleManager.getModule(v);
                if (m == null) continue;
                m.setState(true);
            }
        }
        for (String v : Splited[0].split("\n")) {
            String name = v.split(":")[0];
            String bind = v.split(":")[1];
            Module m = ModuleManager.getModule(name);
            if (m == null) continue;
            m.setKey(Keyboard.getKeyIndex(bind.toUpperCase()));
        }
        for (String v : Splited[1].split("\n")) {
            applyConfig(v);
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static void applyConfig(String config) {
        String name = config.split(":")[0];
        String values = config.split(":")[1];
        Module m = ModuleManager.getModule(name);
        if (m == null) return;
        for (Value value : m.getValues()) {
            if (!value.getName().equalsIgnoreCase(values)) continue;
            if (value instanceof Option) {
                value.setValue(Boolean.parseBoolean(config.split(":")[2]));
                continue;
            }
            if (value instanceof Numbers) {
                value.setValue(Double.parseDouble(config.split(":")[2]));
                continue;
            }
            ((Mode) value).setMode(config.split(":")[2]);
        }
    }
}
